const questions = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Madrid", "Paris", "Lisbon"],
    answer: 2,
  },
  {
    question: "What is 2 + 2?",
    options: ["3", "4", "5", "6"],
    answer: 1,
  },
  // Add more questions as needed
];

let currentQuestionIndex = 0;
let score = 0;
let selectedAnswers = []; // Array to track user answers

// Get DOM elements
const questionElement = document.getElementById("question");
const optionButtons = Array.from(document.getElementsByClassName("option-btn"));
const nextButton = document.getElementById("next-btn");
const feedbackElement = document.getElementById("feedback");
const resultContainer = document.querySelector(".result-container");
const scoreElement = document.getElementById("score");
const restartButton = document.getElementById("restart-btn");
const hintButton = document.getElementById("hint-btn");
const lifelineButton = document.getElementById("lifeline-btn");
const reviewButton = document.getElementById("review-btn");
const reviewContainer = document.getElementById("review-container");
const reviewList = document.getElementById("review-list");
const closeReviewButton = document.getElementById("close-review-btn");

// Load the current question
function loadQuestion() {
  const question = questions[currentQuestionIndex];
  questionElement.innerText = question.question;
  optionButtons.forEach((button, index) => {
    button.innerText = question.options[index];
    button.onclick = () => checkAnswer(index);
  });
  feedbackElement.innerText = "";
  nextButton.disabled = true;
}

// Check the selected answer
async function checkAnswer(selectedIndex) {
  const question = questions[currentQuestionIndex];
  const isCorrect = selectedIndex === question.answer;
  const feedback = isCorrect
    ? "Correct!"
    : `Incorrect. The correct answer was: ${question.options[question.answer]}`;

  if (isCorrect) {
    score++;
  }
  feedbackElement.innerText = feedback;
  nextButton.disabled = false;
}

// Show the final score
function showResult() {
  document.querySelector(".quiz-container").style.display = "none";
  resultContainer.style.display = "block";
  scoreElement.innerText = score;
}

// Restart the quiz
restartButton.addEventListener("click", () => {
  currentQuestionIndex = 0;
  score = 0;
  selectedAnswers = [];
  document.querySelector(".quiz-container").style.display = "block";
  resultContainer.style.display = "none";
  loadQuestion();
});

// Hints
function giveHint() {
  const question = questions[currentQuestionIndex];
  const correctOption = question.options[question.answer];
  feedbackElement.innerText = `Hint: The correct answer contains the word "${correctOption.charAt(
    0
  )}"`;
}

hintButton.addEventListener("click", giveHint);

// 50/50 Lifeline
function lifeline5050() {
  const question = questions[currentQuestionIndex];
  let options = question.options.slice();
  const correctOption = question.answer;
  options.splice(correctOption, 1); // Remove correct option
  const removedOptions = [];
  while (removedOptions.length < 2) {
    const randomIndex = Math.floor(Math.random() * options.length);
    if (!removedOptions.includes(randomIndex)) {
      removedOptions.push(randomIndex);
      options.splice(randomIndex, 1); // Remove incorrect options
    }
  }
  optionButtons.forEach((button, index) => {
    if (!options.includes(index) && index !== correctOption) {
      button.style.display = "none"; // Hide incorrect options
    }
  });
}

lifelineButton.addEventListener("click", lifeline5050);

// Review Answers
function reviewAnswers() {
  reviewList.innerHTML = ""; // Clear previous reviews
  questions.forEach((question, index) => {
    const item = document.createElement("div");
    item.innerText = `Q${index + 1}: ${question.question} - Your Answer: ${
      selectedAnswers[index] !== undefined
        ? questions[index].options[selectedAnswers[index]]
        : "Not answered"
    }`;
    reviewList.appendChild(item);
  });
  reviewContainer.style.display = "block";
}

reviewButton.addEventListener("click", reviewAnswers);
closeReviewButton.addEventListener("click", () => {
  reviewContainer.style.display = "none";
});

// Load initial question
loadQuestion();
