// Define the questions and answers
const questions = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Madrid", "Paris", "Lisbon"],
    answer: 2, // Index of the correct answer
  },
  {
    question: "What is 2 + 2?",
    options: ["3", "4", "5", "6"],
    answer: 1,
  },
  // Add more questions as needed
];

let currentQuestionIndex = 0;
let userResponses = [];

// Display the current question and options
function displayQuestion() {
  const question = questions[currentQuestionIndex];
  document.getElementById("question").textContent = question.question;

  const options = document.querySelectorAll(".option-btn");
  options.forEach((btn, index) => {
    btn.textContent = question.options[index];
    btn.addEventListener("click", () => selectAnswer(index));
  });
}

// Handle answer selection
function selectAnswer(selectedIndex) {
  userResponses[currentQuestionIndex] = selectedIndex;
  document.getElementById("feedback").textContent =
    "You selected option " + (selectedIndex + 1);
}

// Move to the next question
function nextQuestion() {
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    displayQuestion();
  } else {
    document.getElementById("feedback").textContent =
      "Quiz completed! Your responses are recorded.";
    document.querySelector(".options-container").style.display = "none"; // Hide options
    document.getElementById("next-btn").style.display = "none"; // Hide next button
  }
}

// Initialize the quiz
document.getElementById("next-btn").addEventListener("click", nextQuestion);
displayQuestion();
