// Function to update the quantity of an item
function updateQuantity(button, change) {
  const item = button.closest(".card-body");
  const quantityElement = item.querySelector(".quantity");
  let quantity = parseInt(quantityElement.textContent);

  quantity += change;
  if (quantity < 0) quantity = 0;

  quantityElement.textContent = quantity;
  updateTotalPrice();
}

// Function to delete an item from the cart
function deleteItem(button) {
  const item = button.closest(".card");
  item.remove();
  updateTotalPrice();
}

// Function to toggle the like status of an item
function toggleLike(button) {
  button.classList.toggle("liked");
}

// Function to update the total price
function updateTotalPrice() {
  const items = document.querySelectorAll(".card");
  let total = 0;

  items.forEach((item) => {
    const unitPrice = parseFloat(
      item.querySelector(".unit-price").textContent.replace("$", "")
    );
    const quantity = parseInt(item.querySelector(".quantity").textContent);
    total += unitPrice * quantity;
  });

  document.querySelector(".total").textContent = total.toFixed(2) + " $";
}

// Add event listeners to all the necessary buttons
document.addEventListener("DOMContentLoaded", () => {
  // Event listener for quantity buttons
  document.querySelectorAll(".fa-plus-circle").forEach((button) => {
    button.addEventListener("click", () => updateQuantity(button, 1));
  });

  document.querySelectorAll(".fa-minus-circle").forEach((button) => {
    button.addEventListener("click", () => updateQuantity(button, -1));
  });

  // Event listener for delete buttons
  document.querySelectorAll(".fa-trash-alt").forEach((button) => {
    button.addEventListener("click", () => deleteItem(button));
  });

  // Event listener for like buttons
  document.querySelectorAll(".fa-heart").forEach((button) => {
    button.addEventListener("click", () => toggleLike(button));
  });

  // Initialize total price on page load
  updateTotalPrice();
});
