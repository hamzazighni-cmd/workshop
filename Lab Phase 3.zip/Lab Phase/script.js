const questions = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Madrid", "Paris", "Lisbon"],
    answer: 2, // Index of the correct answer
  },
  {
    question: "What is 2 + 2?",
    options: ["3", "4", "5", "6"],
    answer: 1,
  },
  // Add more questions as needed
];

let currentQuestionIndex = 0;
let score = 0;

const feedbackMessages = {
  correct: "Correct!",
  incorrect: (correctAnswer) =>
    `Incorrect. The correct answer was: ${correctAnswer}`,
};

// Get DOM elements
const questionElement = document.getElementById("question");
const optionButtons = Array.from(document.getElementsByClassName("option-btn"));
const nextButton = document.getElementById("next-btn");
const feedbackElement = document.getElementById("feedback");
const resultContainer = document.querySelector(".result-container");
const scoreElement = document.getElementById("score");
const restartButton = document.getElementById("restart-btn");

function loadQuestion() {
  const question = questions[currentQuestionIndex];
  questionElement.innerText = question.question;
  optionButtons.forEach((button, index) => {
    button.innerText = question.options[index];
    button.onclick = () => checkAnswer(index);
  });
  feedbackElement.innerText = "";
  nextButton.disabled = true;
}

function checkAnswer(selectedIndex) {
  const question = questions[currentQuestionIndex];
  if (selectedIndex === question.answer) {
    feedbackElement.innerText = feedbackMessages.correct;
    score++;
  } else {
    feedbackElement.innerText = feedbackMessages.incorrect(
      question.options[question.answer]
    );
  }
  nextButton.disabled = false;
}

function showResult() {
  document.querySelector(".quiz-container").style.display = "none";
  resultContainer.style.display = "block";
  scoreElement.innerText = score;
}

nextButton.addEventListener("click", () => {
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    loadQuestion();
  } else {
    showResult();
  }
});

restartButton.addEventListener("click", () => {
  currentQuestionIndex = 0;
  score = 0;
  document.querySelector(".quiz-container").style.display = "block";
  resultContainer.style.display = "none";
  loadQuestion();
});

// Initial load
loadQuestion();
